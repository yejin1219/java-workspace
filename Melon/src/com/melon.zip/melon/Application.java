package com.melon;
import com.melon.controller.AlbumController;
import com.melon.controller.PaymentInfoController;
import com.melon.controller.UserController;
public class Application {

	public static void main(String[] args) {
		
		
		AlbumController al = new AlbumController();
		PaymentInfoController pa = new PaymentInfoController();
		UserController us = new UserController();
		
		  
		}

}
